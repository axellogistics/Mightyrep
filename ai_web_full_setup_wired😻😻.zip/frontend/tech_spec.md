# AI Web Platform — Tech Spec & DB Schema (MVP)

## Overview
This document covers the minimal tech spec for the GrapesJS + LLM Web-Builder and the Lip-Sync AI pipeline.

## API Endpoints (short)
- `POST /api/auth/register` - register user
- `POST /api/auth/login` - login (JWT)
- `POST /api/projects` - create project
- `PUT /api/projects/:id/save` - save project (html/css/components JSON)
- `POST /api/ai/webbuilder/generate` - generate blocks/copy via LLM
- `POST /api/video/jobs` - create a lip-sync job
- `GET /api/video/jobs/:jobId/status` - job status
- `GET /api/video/jobs/:jobId/result` - download result

## DB Schema (Postgres) - core tables

### users
- id (uuid, PK)
- email (varchar, unique)
- name (varchar)
- password_hash (varchar)
- role (varchar) -- 'user'|'admin'
- created_at (timestamp)
- settings (jsonb)

### projects
- id (uuid, PK)
- owner_id (uuid, FK -> users.id)
- name (varchar)
- description (text)
- live_url (varchar)
- created_at (timestamp)
- updated_at (timestamp)

### project_versions
- id (uuid, PK)
- project_id (uuid, FK)
- version_number (int)
- html (text)
- css (text)
- components_json (jsonb)
- assets (jsonb)
- created_at (timestamp)

### video_jobs
- id (uuid, PK)
- user_id (uuid, FK)
- input_video_url (varchar)
- input_audio_url (varchar)
- options (jsonb)
- status (varchar) -- 'queued'|'processing'|'done'|'failed'
- created_at, started_at, finished_at (timestamps)
- output_url (varchar)
- sync_score (float)
- meta (jsonb)

## Prompts (examples)
- Web-Builder system prompt: 'You are SiteForge, an expert website designer. Output JSON with keys html and css only.'
- Example user prompt: 'Create a responsive hero for "Axel Logistics". Tone: professional.'

## Model Infra (worker)
- GPU docker image with Wav2Lip + Real-ESRGAN (optional)
- Worker downloads media from S3, runs inference, uploads output, updates API via callback.

## Security & Privacy
- Signed short-lived URLs for media
- Explicit consent checkbox per job
- Data retention policy: default delete after 30 days unless user opts in

