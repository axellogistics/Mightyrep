GrapesJS + LLM demo (Next.js)
--------------------------------
Files:
- pages/webbuilder-demo.js  (frontend demo using GrapesJS)
- pages/api/ai/generate-hero.js  (API route - mock LLM response by default)
- package.json

Notes:
- Replace OPENAI_API_KEY in environment to enable real OpenAI calls.
- This demo is intentionally minimal and returns a safe hardcoded JSON hero when no API key is present.


Client env vars needed:
- NEXT_PUBLIC_BACKEND_URL (e.g. https://api.example.com)
- NEXT_PUBLIC_CLIENT_KEY
