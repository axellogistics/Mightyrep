
import { useEffect } from 'react';
import grapesjs from 'grapesjs';
import 'grapesjs/dist/css/grapes.min.css';

export default function WebBuilderDemo() {
  useEffect(() => {
    const editor = grapesjs.init({
      container: '#gjs',
      fromElement: false,
      height: '640px',
      width: '100%',
      storageManager: false,
      components: '<section class="hero"><h1>Welcome</h1><p>Click the AI button to generate a hero</p></section>',
    });

    window.insertHero = async () => {
      try {
        const backend = (process.env.NEXT_PUBLIC_BACKEND_URL || '').replace(/\/$/, '');
        if (!backend) {
          alert('Please set NEXT_PUBLIC_BACKEND_URL in your environment to point to the backend (e.g. https://api.example.com)');
          return;
        }
        const res = await fetch(backend + '/api/ai/generate-hero', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-client-key': (process.env.NEXT_PUBLIC_CLIENT_KEY || '')
          },
          body: JSON.stringify({ prompt: 'Create a responsive hero for Axel Logistics. Tone: professional.' })
        });
        const json = await res.json();
        if (json.error) {
          alert('AI API error: ' + json.error);
          return;
        }
        // Insert returned HTML as a new block/component
        editor.addComponents(json.html);
        if (json.css) {
          const css = editor.CssComposer;
          css.add(json.css);
        }
        alert('AI hero inserted into the canvas.');
      } catch (e) {
        alert('Error calling AI API: ' + e.message);
      }
    };
  }, []);

  return (
    <div style={{padding:20}}>
      <div style={{marginBottom:12}}>
        <button onClick={() => window.insertHero()}>Generate Hero (AI)</button>
      </div>
      <div id="gjs" />
      <div style={{padding:20}}>
        <small>Make sure NEXT_PUBLIC_BACKEND_URL and NEXT_PUBLIC_CLIENT_KEY are set in your Vercel or local env.</small>
      </div>
    </div>
  );
}
