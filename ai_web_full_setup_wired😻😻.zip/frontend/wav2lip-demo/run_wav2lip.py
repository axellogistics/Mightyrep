#!/usr/bin/env python3
# run_wav2lip.py -- minimal wrapper that expects the Wav2Lip repo and checkpoints to be mounted alongside this container.
# This script will attempt to call the Wav2Lip inference script if available; otherwise it will raise a helpful message.
import os, subprocess, sys, argparse, shutil

parser = argparse.ArgumentParser()
parser.add_argument('--video', required=True, help='Path to input video (face video)')
parser.add_argument('--audio', required=True, help='Path to input audio file (wav/mp3)')
parser.add_argument('--out', default='/app/out.mp4', help='Output path')
parser.add_argument('--use_sr', action='store_true', help='Run super-resolution (Real-ESRGAN) if available')
args = parser.parse_args()

# Expect the Wav2Lip repo to be at /app/Wav2Lip (mounted by user) with checkpoints in /app/Wav2Lip/checkpoints/
wav2lip_path = '/app/Wav2Lip'
if not os.path.exists(wav2lip_path):
    print('Wav2Lip repo not found at /app/Wav2Lip. Please mount the official Wav2Lip repository to /app/Wav2Lip inside the container.', file=sys.stderr)
    sys.exit(2)

checkpoint = os.path.join(wav2lip_path, 'checkpoints', 'wav2lip_gan.pth')
if not os.path.exists(checkpoint):
    print('Wav2Lip checkpoint not found at', checkpoint, file=sys.stderr)
    print('Download the checkpoint and place it in /app/Wav2Lip/checkpoints/', file=sys.stderr)
    sys.exit(2)

# call the Wav2Lip inference entrypoint (this path may vary by repo)
inference_script = os.path.join(wav2lip_path, 'inference.py')
if not os.path.exists(inference_script):
    print('Wav2Lip inference script not found at', inference_script, file=sys.stderr)
    sys.exit(2)

cmd = ['python3', inference_script, '--checkpoint_path', checkpoint, '--face', args.video, '--audio', args.audio, '--outfile', args.out]
print('Running:', ' '.join(cmd))
subprocess.check_call(cmd)

# Optionally run Real-ESRGAN if requested and available
if args.use_sr:
    sr_script = '/app/Real-ESRGAN/inference_realesrgan.py'
    if os.path.exists(sr_script):
        out_sr = args.out.replace('.mp4', '_sr.mp4')
        cmd2 = ['python3', sr_script, '-i', args.out, '-o', out_sr]
        print('Running SR:', ' '.join(cmd2))
        subprocess.check_call(cmd2)
        print('Super-res output at', out_sr)
    else:
        print('Real-ESRGAN not found at /app/Real-ESRGAN; skipping super-resolution.')
