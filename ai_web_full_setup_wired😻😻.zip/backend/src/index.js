
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fetch = require('node-fetch');
const sanitizeHtml = require('sanitize-html');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 4000;

// Simple client key check: frontend must send header 'x-client-key' that matches CLIENT_KEY env var.
const CLIENT_KEY = process.env.CLIENT_KEY || 'change_this_client_key';

function sanitizePrompt(input) {
  if (!input || typeof input !== 'string') return '';
  // strip HTML, limit length
  const cleaned = sanitizeHtml(input, { allowedTags: [], allowedAttributes: {} });
  return cleaned.trim().slice(0, 1000); // max 1000 chars
}

app.get('/health', (req, res) => res.json({status:'ok'}));

// Existing example endpoints...
app.post('/api/projects', (req,res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({error:'name required'});
  return res.json({id:'proj_' + Date.now(), name});
});

// New endpoint: AI generate hero (server-side call to OpenAI)
// Expects: { prompt?: string } in JSON body
// Requires header: x-client-key === CLIENT_KEY
app.post('/api/ai/generate-hero', async (req, res) => {
  try {
    const clientKey = req.headers['x-client-key'];
    if (!clientKey || clientKey !== CLIENT_KEY) {
      return res.status(401).json({ error: 'Unauthorized (invalid client key)' });
    }

    const rawPrompt = req.body && req.body.prompt ? String(req.body.prompt) : '';
    const prompt = sanitizePrompt(rawPrompt) || 'Create a responsive hero section for a professional logistics company named "Axel Logistics". Output JSON with keys: html, css.';

    // If no OpenAI key is configured, return demo fallback
    const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
    const demo = {
      html: `<section class="ai-hero" style="padding:48px 24px;display:flex;gap:24px;align-items:center;">
        <div style="flex:1">
          <h1 style="font-size:32px;margin:0">Axel Logistics — Reliable Airport Security &amp; Staff</h1>
          <p style="margin-top:8px;color:#444">Apply for airport attendant and security roles. Fast onboarding, competitive pay.</p>
          <div style="margin-top:12px">
            <a href="#apply" style="display:inline-block;padding:10px 18px;background:#0b63ff;color:white;border-radius:6px;text-decoration:none;">Apply Now</a>
          </div>
        </div>
        <div style="width:320px;height:180px;background:#eee;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#888">Image</div>
      </section>`,
      css: `.ai-hero h1{line-height:1.05}.ai-hero p{font-size:16px}`
    };

    if (!OPENAI_API_KEY) {
      return res.status(200).json(demo);
    }

    // Call OpenAI Chat Completions (server-side)
    const payload = {
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are SiteForge, an assistant that outputs a JSON object with keys html and css only.' },
        { role: 'user', content: prompt }
      ],
      max_tokens: 700,
      temperature: 0.2
    };

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload),
      timeout: 30000
    });

    if (!response.ok) {
      console.error('OpenAI error', await response.text());
      return res.status(502).json(demo);
    }

    const data = await response.json();
    const text = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    try {
      const parsed = JSON.parse(text);
      // Basic sanitization on returned html: remove script tags
      parsed.html = sanitizeHtml(parsed.html || '', { allowedTags: sanitizeHtml.defaults.allowedTags.concat(['img','section','div','h1','h2','h3','p','a','ul','li']), allowedAttributes: false });
      parsed.css = String(parsed.css || '').slice(0, 5000);
      return res.status(200).json(parsed);
    } catch (e) {
      // If model returned non-JSON, fallback to demo
      return res.status(200).json(demo);
    }
  } catch (err) {
    console.error('Server error in /api/ai/generate-hero', err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

// Video job creation uses BullMQ (unchanged)
const { Queue } = require('bullmq');
const IORedis = require('ioredis');
const connection = new IORedis(process.env.REDIS_URL || 'redis://localhost:6379');
const videoQueue = new Queue('video-jobs', { connection });

app.post('/api/video/jobs', async (req,res) => {
  const { inputVideoUrl, inputAudioUrl, options } = req.body;
  if (!inputVideoUrl || !inputAudioUrl) return res.status(400).json({error:'video and audio required'});
  const job = await videoQueue.add('lip-sync', { inputVideoUrl, inputAudioUrl, options }, { attempts: 3 });
  return res.json({ jobId: job.id, status: 'queued' });
});

app.listen(PORT, () => console.log('Backend listening on', PORT));
