
const knex = require('knex');
const db = knex({
  client: 'pg',
  connection: process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/ai_web'
});

async function migrate(){
  console.log('Running migrations...');
  await db.schema.hasTable('users').then(async exists => {
    if (!exists) {
      await db.schema.createTable('users', t => {
        t.uuid('id').primary().defaultTo(db.raw('gen_random_uuid()'));
        t.string('email').unique();
        t.string('name');
        t.string('password_hash');
        t.string('role').defaultTo('user');
        t.timestamp('created_at').defaultTo(db.fn.now());
      });
    }
  });

  await db.schema.hasTable('projects').then(async exists => {
    if (!exists) {
      await db.schema.createTable('projects', t => {
        t.uuid('id').primary().defaultTo(db.raw('gen_random_uuid()'));
        t.uuid('owner_id');
        t.string('name');
        t.text('description');
        t.string('live_url');
        t.timestamp('created_at').defaultTo(db.fn.now());
      });
    }
  });

  console.log('Migrations complete.');
  process.exit(0);
}

migrate().catch(e => { console.error(e); process.exit(1); });
