
# AI Web Platform — Setup & Deployment Guide

This repository contains:
- `frontend/` : GrapesJS + LLM Next.js demo (from previous package)
- `backend/` : Production-ready backend scaffold (Express + Postgres + Redis + BullMQ worker)
- `infra/` : Docker Compose for local development
- `ci/` : GitHub Actions workflows (including Vercel deploy workflow)
- `docs/` : Tech spec and other docs

--- 

## Quick start (local, dev)

Prereqs:
- Node.js 18+ and npm
- Docker & Docker Compose (for local Postgres/Redis/worker)
- (Optional) GPU host for Wav2Lip processing

1. Clone repo:
   ```bash
   git clone <your-repo-url>
   cd ai-web-platform
   ```

2. Start infrastructure:
   ```bash
   cd infra
   docker compose up -d
   ```

3. Install backend deps and run:
   ```bash
   cd backend
   npm install
   npm run dev
   ```

4. Frontend (Next.js demo):
   ```bash
   cd frontend/grapesjs-llm-demo
   npm install
   npm run dev
   # open http://localhost:3000/webbuilder-demo
   ```

## Deploy Next.js to Vercel (copy/paste)

1. Push your frontend to GitHub.
2. Create a Vercel account and connect your GitHub repository.
   - New Project → Import GitHub Repository → select the frontend repo.
3. In Vercel Dashboard → Project Settings → Environment Variables:
   - Add `OPENAI_API_KEY` (Environment: Preview + Production)
   - If you need server-only keys, **do not** prefix with NEXT_PUBLIC_
4. Deploy: Vercel will auto-deploy on pushes to `main`. Or from CLI:
   ```bash
   npm i -g vercel
   vercel login
   vercel --prod
   ```

References: Vercel docs on Deploying and Environment Variables.
